/* Distance Constructor */
#include <iostream>
using namespace std;

class dist{
  private:
  int inch,feet;

  public:
  dist()
  {
    cin>>feet>>inch;
  }
  void calc(dist x,dist y)
  {
    feet=x.feet+y.feet;
    inch=x.inch+y.inch;
    if(inch>12)
    {
      inch-=12;
      feet++;
    }
  }

  void display()
  {
    cout<<feet<<" feet "<<inch<<" inch";
  }
};

int main() {
    dist a,b,result;
    result.calc(a,b);
    result.display();
    return 0;
};