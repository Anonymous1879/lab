/* Temperature */
#include <iostream>
using namespace std;

class centigrade{
  float x,y;

  public:
  centigrade()
  {
    cin>>x;
  }
  void convert()
  {
    y=(x*1.8)+32;
    cout<<x<<"C:"<<y<<"F"<<endl;

  }
};

class fahrenheit{
  float x,y;

  public:
  fahrenheit()
  {
    cin>>x;
  }
  void convert()
  {
    y=((x-32)*5)/9.0;
    cout<<x<<"F:"<<y<<"C"<<endl;
  }
};
int main() {
    centigrade a;
    fahrenheit b;
    a.convert();
    b.convert();
    return 0;
};