/* Order of constructor and destructor invocation */
#include <iostream>
using namespace std;

class ab{
    int x;
    public:
    ab(int a)
    {
        x=a;
        cout<<"Constructor "<<x<<" created."<<endl;
    }
    ~ab()
    {
        cout<<"Constructor "<<x<<" destructed."<<endl;
    }
};

int main() {
    ab a(1),b(2),c(3);
    return 0;
};
/*
Here, we can see that the constructor is executed in the order it is written. a(1) then b(2) then c(3) but the destructor is called in reverse order of constructor.
The constructor which is created last is destructed first and the constructor which is created first gets destrcuted last.

constructor -> a->b->c
destructor -> c->b->a
*/