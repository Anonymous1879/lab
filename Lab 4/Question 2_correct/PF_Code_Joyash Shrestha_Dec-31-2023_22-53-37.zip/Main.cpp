/* Sum and difference using constructor and function overloading */
#include <iostream>
using namespace std;

class complex{

    int real;
    int img;
    public:
    complex()
    {
        real=0;
        img=0;
    }

    complex(int x,int y)
    {
        real=x;
        img=y;
    }

    void op(complex a,complex b)
    {
        real=a.real+b.real;
        img=a.img+b.img;
    }

    complex op(complex pass)
    {
        complex result;
        result.real=real-pass.real;
        result.img=img-pass.img;
        return result;
    }

    void display()
    {
        cout<<real<<"+"<<img<<"i"<<endl;
    }
};
int main() {
    complex x(3,4),y(1,2),sum,diff;
    sum.op(x,y);
    diff=x.op(y);
    cout<<"Sum:"<<endl;
    sum.display();
    cout<<"Difference:"<<endl;
    diff.display();
    return 0;
};