/* Friend Function */
#include <iostream>
using namespace std;

class x;
class y{
  int data2=1;
  friend void greatest(x,y);
};
class x{
  int data1=2;
  friend void greatest(x,y);
};

void greatest(x first,y second)
{
  if(first.data1>second.data2)
    cout<<"data1 is greatest";
  else
    cout<<"data2 is greatest";
}
int main() {
    x first;
    y second;
    greatest(first,second);
    return 0;
};