/* Time Constructor */
#include <iostream>
using namespace std;

class Time{
  private:
  int hrs,min,sec;
  public:
  Time()
  {
    hrs=0,min=0,sec=0;
  }
  Time(int x,int y,int z)
  {
    hrs=x,min=y,sec=z;
  }

  void add(Time a,Time b)
  {
    hrs=a.hrs+b.hrs;
    min=a.min+b.min;
    sec=a.sec+b.sec;
    if(sec>60)
    {
      sec-=60;
      min++;
    }
    if(min>60)
    {
      min-=60;
      hrs++;
    }
  }
  void display()
  {
    cout<<hrs<<":"<<min<<":"<<sec;
  }
};
int main() {
    Time a(12,34,56),b(10,35,14),c;
    c.add(a,b);
    c.display();
    return 0;
};