/* CONVERT A CENTIGRADE CLASS INTO OBJECT OF ANOTHER CLASS FAHRENHEIT */
/* DEFINE CONVERSION IN DESINATION CLASS*/


#include <iostream>
using namespace std;

class celcius
{
    float c;

    public:
    celcius()
    {
        c=0;
    }
    celcius(int x)
    {
        c=x;
    }

    float data()
    {
        return c;
    }
};

class fahrenheit
{
    float f;

    public:
    fahrenheit()
    {
        f=0;
    }
    fahrenheit(int x)
    {
        f=x;
    }

    fahrenheit(celcius X)
    {
        f=((X.data()*9)/5)+32;
    }

    void display()
    {
        cout<<f;
    }
};

int main() {
    celcius temp(50);
    fahrenheit result;
    result=temp;
    result.display();
    return 0;
};