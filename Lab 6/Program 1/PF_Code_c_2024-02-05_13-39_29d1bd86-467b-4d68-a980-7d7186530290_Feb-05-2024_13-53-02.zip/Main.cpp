/* WAP TO CONVERT HOUR INTO OBJECT OF A CLASS TIME WHICH HAS MIN AND SEC AS MEMBER */
#include <iostream>
using namespace std;

class times
{
    int min;
    int sec;

    public:
    times()
    {
        min=0;
        sec=0;
    }

    times(int hr)
    {
        min=hr*60;
        sec=hr*60*60;
    }
    void display()
    {
        cout<<"min:"<<min<<"\nsec:"<<sec;
    }
};

int main() {
    int hour=3;
    times T1;
    T1=hour;
    T1.display();
    return 0;
}