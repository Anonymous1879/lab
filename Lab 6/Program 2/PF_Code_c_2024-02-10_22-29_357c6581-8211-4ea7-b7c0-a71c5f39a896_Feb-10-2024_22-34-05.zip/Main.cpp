/* WAP TO EXPRESS MINUTES AND SECONDS INTO A SINGLE HOUR VALUE */
#include <iostream>
using namespace std;

class Tim
{
    int min;
    int sec;

    public:
    Tim()
    {
        min=0;
        sec=0;
    }

    Tim(int x,int y)
    {
        min=x;
        sec=y;
    }

    operator float()
    {
        float temp;
        temp=sec/60.0;
        temp=(temp+min)/60.0;
        return temp;
    }
};
int main() {
    Tim T1(70,30);
    float hr;
    hr=T1;
    cout<<hr;
    return 0;
};