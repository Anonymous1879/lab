/* CREATE A CENTIGRADE CLASS INTO OBJECT OF ANOTHER CLASS FAHRENHEIT */
/* DEFINE CONVERSION ROUTINE IN SOURCE CLASS */

#include <iostream>
using namespace std;

class celcius
{
    
    public:
    float x;
    celcius()
    {
        x=0;
    }

    void display()
    {
        cout<<x;
    }
};

class fahrenheit
{
    float x;

    public:
    fahrenheit()
    {
        x=0;
    }

    fahrenheit(float a)
    {
        x=a;
    }
    operator celcius()
    {
       celcius temp;
        temp.x=(x-32)*5.0/9.0;
        return temp;
    }

};

int main() {
    fahrenheit T1(50);
    celcius T2;
    T2=T1;
    T2.display();
    return 0;
};