/* ABSTRACT CLASS */
#include <iostream>
using namespace std;

class ABC
{
    public:
    int a;
    virtual void getdata()
    {
        cin>>a;
    }

    virtual void display()=0;
};

class plusone:public ABC
{
    public:

    void display()
    {
        cout<<a+1<<endl;
    }

};

class plustwo:public ABC
{
    public:

    void display()
    {
        cout<<a+2<<endl;
    }
};

int main() {
    plusone A;
    A.getdata();
    plustwo B;
    B.getdata();
    A.display();
    B.display();
    return 0;
};