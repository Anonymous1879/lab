/* Program 2 */
#include <iostream>
#include <cstring>

using namespace std;

class staff
{
    int staff_id;

    public:
    staff()
    {
        staff_id=0;
    }
    staff(int x)
    {
        staff_id=x;
    }
    void return_id()
    {
        cout<<staff_id<<endl;
    }
};

class lecturer:public staff
{
    char subject[10];

    public:

    lecturer()
    {
        strcpy(subject,"x");
    }
    lecturer(char x[10],int y):staff(y)
    {
        strcpy(subject,x);
    }

    void return_subject()
    {
        cout<<"Subject:"<<subject<<endl;
    }
};

class admin:public staff
{
    char post_dept[10];

    public:
    admin()
    {
        strcpy(post_dept,"x");
    }

    admin(char x[10],int y):staff(y)
    {
        strcpy(post_dept,x);
    }

    void return_dept()
    {
        cout<<"Post Department:"<<post_dept<<endl;
    }
};

class librarian:public staff
{
    char shift[10];
    
    public:
    librarian()
    {
        strcpy(shift,"x");
    }

    librarian(char x[10],int y):staff(y)
    {
        strcpy(shift,x);
    }
    void return_shift()
    {
        cout<<"Shift:"<<shift<<endl;
    }
};

int main() {
    char subject[10];
    char dept[10];
    char shift[10];
    cin>>subject;
    cin>>dept;
    cin>>shift;
    lecturer L1(subject,1);
    admin A1(dept,2);
    librarian L2(shift,3);
    L1.return_id();
    L1.return_subject();
    A1.return_id();
    A1.return_dept();
    L2.return_id();
    L2.return_shift();
    return 0;
};