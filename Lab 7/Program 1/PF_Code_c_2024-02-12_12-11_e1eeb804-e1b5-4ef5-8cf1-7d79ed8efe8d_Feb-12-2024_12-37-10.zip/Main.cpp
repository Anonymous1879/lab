/* WAP TO ILLUSTRATE SINGLE, MULTIPLE, MULTILEVEL, HEIRARCHIAL INHERITANCE */

#include <iostream>
using namespace std;

class base
{
    int x;

    public:
    void display()
    {
        cout<<x<<endl;
    }

    void input()
    {
        cin>>x;
    }
};

class base1
{
    int y;

    public:
    void display1()
    {
        cout<<y<<endl;
    }

    void input1()
    {
        cin>>y;
    }
};

class heirarchial2:public base{
    int z;

    public:
    void getdata()
    {
    cin>>z;
    }

    void showdata()
    {
    cout<<z<<endl;
    }
};

class heirarchial1:public base{}; 

class multiple:public base,public base1{};

class multilevel:public heirarchial2{};

class ABC
{
    int x=5;

    public:
    void display()
    {
        cout<<x;
    }
};

class single:public ABC{};

int main() {
    base A1;
    heirarchial2 B1;
    multiple C1;
    A1.input();
    B1.input();
    A1.display();
    B1.display();
    C1.input();
    C1.input1();
    C1.display();
    multilevel D1;
    D1.input();
    D1.getdata();
    D1.showdata();
    heirarchial1 E1;
    E1.input();
    E1.display();
    single F1;
    F1.display();
    return 0;
};