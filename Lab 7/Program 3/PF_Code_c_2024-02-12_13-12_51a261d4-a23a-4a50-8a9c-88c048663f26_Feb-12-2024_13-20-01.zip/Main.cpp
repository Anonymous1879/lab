/* Virtual Class */
#include <iostream>
using namespace std;

class shape
{
    int length;
    int breadth;

    public:
    int area;
    void getdata()
    {
        cin>>length;
        cin>>breadth;
    }

    void calc_area()
    {
        area=length*breadth;
    }

    virtual void display_area()
    {
        cout<<"Area is 0";
    }

};

class rectangle:public shape
{
    public:
    void display_area()
    {
        cout<<"Area is "<<area<<endl;
    }
};

int main() {
    rectangle R1;
    R1.getdata();
    R1.calc_area();
    R1.display_area();
    return 0;
};