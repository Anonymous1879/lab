/* Return by reference */
#include <iostream>
using namespace std;

class Temp{
  public:
  int t1;
  int t2;

  void input()
  {
  cout<<"Enter temperatues:"<<endl;
  cin>>t1>>t2;
  }

  int& compare(int &a,int &b)
  {
    if(a>b)
      return a;
    else
      return b;
  }
};
int main() {
  Temp T;
  T.input();
  T.compare(T.t1,T.t2)=100;
  cout<<"The temperatures are "<<T.t1<<","<<T.t2;
  return 0;
};