/* Inline Function */
#include <iostream>
using namespace std;

class employee{
  private:
  float salary;
  float tax;

  public:
  void input()
  {
    cout<<"Enter salary"<<endl;
    cin>>salary;
  }

  inline void display_salary()
  {
    tax=salary/10.0;
    salary=salary-tax;
    cout<<"Salary is "<<salary;
  }
  
};


int main() {
  employee E;
  E.input();
  E.display_salary();
};