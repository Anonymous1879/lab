/* Sample C++ code */
#include <iostream>
using namespace std;

class avg{
  private:
  int *p,sum=0;
  float a;

  public:
  void input()
  {
  p=new int[10];
  cout<<"Enter 10 numbers:\n";
  for(int i=0;i<10;i++)
  cin>>p[i];
  }
  
  void calculate()
  {
  for(int i=0;i<10;i++)
  sum=sum+p[i];
  a=static_cast<float>(sum)/10.0;
  cout<<"Average is "<<a;
  delete []p;
  }
};
int main() {
  avg A;
  A.input();
  A.calculate();

  return 0;
};