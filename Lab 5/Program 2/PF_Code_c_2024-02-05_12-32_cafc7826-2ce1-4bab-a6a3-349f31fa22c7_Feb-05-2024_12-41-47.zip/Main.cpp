/* WAP TO OVERLOAD INCREMENT OPERATOR IN (++) PREFIX NOTATION */
#include <iostream>
using namespace std;

class abc{
    int x,y;

    public:
    abc()
    {
        x=0,y=0;
    }

    abc(int a,int b)
    {
        x=a,y=b;
    }

    void operator ++()
    {
        ++x;
        ++y;
    }
    void display()
    {
        cout<<x<<","<<y;
    }
};
int main() {
    abc A(1,2);
    ++A;
    A.display();
    return 0;
};