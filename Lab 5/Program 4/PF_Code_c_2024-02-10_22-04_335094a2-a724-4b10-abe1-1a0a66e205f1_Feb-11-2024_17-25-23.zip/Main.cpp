/* WAP TO OVERLOAD UNARY MINUS OPERATOR USING FRIEND FUNCTION */
#include <iostream>
using namespace std;

class abc
{
    int a,b;

    public:
    abc()
    {
        a=0;
        b=0;
    }

    abc(int x,int y)
    {
        a=x;
        b=y;
    }

    friend abc operator -(abc);

    void display()
    {
        cout<<a<<","<<b;
    }
};

abc operator -(abc temp)
{
    temp.a=-temp.a;
    temp.b=-temp.b;
    return temp;
}
int main() {
    abc X(1,2),result;
    result=-X;
    result.display();
    return 0;
};