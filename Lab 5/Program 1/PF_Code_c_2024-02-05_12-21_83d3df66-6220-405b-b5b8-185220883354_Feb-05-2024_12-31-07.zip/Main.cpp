/* WAP TO SHOW OPERATOR FUNCTION RETURN OBJECT OF TYPE COMPLEX */
#include <iostream>
using namespace std;

class complex{
    private:
    int real;
    int img;

    public:
    complex()
    {
        real=0;
        img=0;
    }

    complex(int x,int y)
    {
        real=x;
        img=y;
    }

    complex operator+(complex b)
    {
        complex temp;
        temp.real=real+b.real;
        temp.img=img+b.img;
        return temp;
    }

    void display()
    {
        cout<<real<<"+"<<img<<"i";
    }
};

int main() {
    complex A(1,2),B(2,3),result;
    result=A+B;
    result.display();
    return 0;
};