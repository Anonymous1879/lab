/* WAP TO OVERLOAD PLUS OPERATOR TO ADD TWO COMPLEX NUMBERS USING FRIEND FUNCTION */
#include <iostream>
using namespace std;

class complex
{
    int real;
    int img;

    public:
    complex()
    {
        real=0;
        img=0;
    }

    complex(int a,int b)
    {
        real=a;
        img=b;
    }

    friend complex operator+(complex,complex);

    void display()
    {
        cout<<real<<"+"<<img<<"i";
    }
};

complex operator+(complex a,complex b)
{
    complex temp;
    temp.real=a.real+b.real;
    temp.img=a.img+b.img;
    return temp;
}

int main() {
    complex A(1,2),B(2,3),result;
    result=A+B;
    result.display();
    return 0;
};