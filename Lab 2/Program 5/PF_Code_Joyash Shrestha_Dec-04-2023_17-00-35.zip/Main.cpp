/* display characters with default argument */
#include <iostream>
using namespace std;

void display(int n=1,char a='J')
{
    cout<<"character "<<n<<":"<<a<<endl;
}
int main() {
    int n;
    char x;

    cout<<"Enter number of characters:";
    cout<<"\n";
    cin>>n;

    cout<<"Enter "<<n<<" characters:"<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>x;
        display(i+1,x);
    }
    display(6);
    display();

    return 0;
};