/* Volume using function overloading */
#include <iostream>
using namespace std;
#define pi 3.14

float volume(int l)
{
    return(l*l*l);
}

float volume(int r,int h)
{
    return(pi*r*r*h);
}

float volume(int l,int b,int h)
{
    return(l*b*h);
}

int main() {
    int l,b,h,r;
    float result;
    cout<<"Enter length of cube:";
    cin>>l;
    result=volume(l);
    cout<<"\nVolume of cube is "<<result;
    cout<<"\nEnter length, breadth and height of cuboid:";
    cin>>l>>b>>h;
    result=volume(l,b,h);
    cout<<"\nVolume of cuboid is "<<result;
    cout<<"\nEnter radius and height of cylinder:"<<endl;
    cin>>r>>h;
    result=volume(r,h);
    cout<<"Volume of cylinder is "<<result;
    return 0;
};