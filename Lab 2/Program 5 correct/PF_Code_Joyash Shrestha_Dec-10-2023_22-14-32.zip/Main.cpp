/* Display character with default value */
#include <iostream>
using namespace std;

void display(int n=1,char a='j')
{
    cout<<endl;
    for(int i=0;i<n;i++){
        cout<<a<<endl;
    }
    cout<<n;
}


int main() {
    int n;
    char a;
    cout<<"Enter number";
    cin>>n;
    cout << "\nEnter character";
    cin>>a;
    display(n,a);
    display(5);
    return 0;
};